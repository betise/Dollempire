PgwSlider
=========

The full documentation and an example are available on [PgwJS.com](http://pgwjs.com/pgwslider/).


Requirements
---------

jQuery 1.0 or Zepto.js 1.0 (minimal version)


Contributing
---------

All any issues or pull requests must be submitted through GitHub.

* To report an issue or a feature request, please use [GitHub Issues](https://github.com/Pagawa/PgwSlider/issues).
* To make a pull request, please create a new branch for each feature or issue.


Changelog
---------

* 2014-03-22 - Even simpler initialization and the "Data-title" parameter becomes "alt".  
* 2014-03-21 - Cleaning code and adding new options - Minor update (Version 1.1).  
